class Mamifero{
    constructor(patas){
        this.patas = patas
    }
}// o método construtor existe para que seja possível estanciar um objeo na classe

let coiote = new Mamifero(4);
console.log(coiote.patas);
//herança na parada!

class Cachorro extends Mamifero{
    constructor(patas, raca){
        super(patas,patas);
        this.raca = raca;
    }
    latir(){
        console.log('Au Au');
    }
}//fim classe
let pug = new Cachorro(4, "Pug");
console.log(pug.patas);
pug.latir();

   


