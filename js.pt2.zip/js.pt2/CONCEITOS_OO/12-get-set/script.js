class Cachorro {
    constructor(raca,cor) {

        this.raca = raca;
        this.cor = cor;
    }
    latir(){
        console.log("Au Au Au");
    }

    get getCor(){
        return this.cor;
    }
    set setCor(cor){ //parâmetro-característica
        this.cor = cor;
    }

}// fim da classe

let pastor = new  Cachorro('Pastor Alemão', 'Sem cor');
console.log(pastor);
pastor.setCor = 'Marrom';
console.log(pastor.getCor); //getCor é um método

